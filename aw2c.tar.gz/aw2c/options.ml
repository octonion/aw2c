(* options.ml -- global compiler flags *)

let trace = ref false (** If true, insert procedure call tracing code *)

(* end *)
