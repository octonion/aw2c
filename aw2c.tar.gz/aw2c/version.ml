let release = "ela:/home/glyn/Aw2c/aw2c - Mon Apr 27 14:25:27 NZST 2009  glyn"
